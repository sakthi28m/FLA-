# Finite Automata and Pushdown Automata for Form Validation and Expression Parsing

CLA-2 Assessment Tasks 2 and 3 (individual work)
**Course:** 21CSC301T – Formal Language and Automata, SRM Institute of Science and Technology, Tiruchirappalli
**Student:** Shivanand (RA2411026050242) · **Guide:** Dr. C. Gunasundari, Dept. of AIML

The report is in [`report/`](report/) (Word and PDF). This repository holds the code behind it.

## What is implemented

| Task | Case | Model | States |
|------|------|-------|--------|
| 2 | PAN number `AAAPA9999A` | DFA | 12 (incl. trap) |
| 2 | 24-hour time `HH:MM` | DFA | 8 |
| 2 | IPv4 dotted decimal (0-255, no leading zeros) | DFA | 25 |
| 3 | Arithmetic expressions (`id + * ( )`) | LL(1) DPDA, unambiguous CFG | 3 |
| 3 | Even-length palindromes `w wR` | NPDA (marked version is a DPDA) | 3 |
| 3 | Floating-point literals | CFG that is regular, DFA | 9 |

All DFAs run through one table-driven runner with a character classifier and a trap state.
The ambiguous grammar `E -> E+E | E*E | (E) | id` is used only to count parse trees and as a reference for the parser.

## Run it

Python 3.9+ and the standard library are enough for `validators.py`.

```bash
python3 validators.py table dfa              # verdicts for the three DFAs
python3 validators.py table pda              # verdicts for the three case studies
python3 validators.py trace pan ABCPE1234F   # step-by-step trace
python3 validators.py trace ip 256.1.1.1
python3 validators.py trace expr "id+id*id"
python3 validators.py trace pal abba
python3 validators.py trace marked abcba
python3 validators.py trace float -0.5e10
python3 validators.py verify dfa             # exhaustive + random check against regex / ipaddress
python3 validators.py verify pda             # check against Earley parser, regex, direct palindrome test
```

Trace names: `pan`, `time`, `ip`, `expr`, `pal`, `marked`, `float`.

## How it is tested

* `pytest` runs the accepted/rejected tables from the report, state counts, minimality of each DFA and small exhaustive comparisons.
* `verify dfa` / `verify pda` run the full comparisons quoted in the report (millions of strings, 0 mismatches).
* Independent references: Python `re`, the `ipaddress` module, a generic Earley recogniser, and a direct palindrome check.

```bash
pip install -r requirements.txt
pytest -q
```

## Regenerate the figures

Needs Graphviz (`dot`) and Pillow. Diagrams and terminal-style screenshots are written to `fig/`.

```bash
python3 figures.py
```

## Layout

```
validators.py        DFAs, PDAs, grammars, command line
figures.py           diagrams (Graphviz) and terminal-style screenshots
tests/               pytest suite
fig/                 figures used in the report
report/              report (.docx and .pdf)
```

## Reference

J. E. Hopcroft, R. Motwani and J. D. Ullman, *Introduction to Automata Theory, Languages, and Computation*, 3rd ed., Pearson, 2007.
