#!/usr/bin/env python3
"""
Finite automata and pushdown automata for form validation and expression parsing.

Task 2 (DFAs):   PAN number, 24-hour time (HH:MM), IPv4 dotted-decimal address
Task 3 (PDA/CFG): arithmetic expressions, even-length palindromes, float literals

Usage:
    python3 validators.py table dfa
    python3 validators.py table pda
    python3 validators.py trace <pan|time|ip|expr|pal|marked|float> <string>
    python3 validators.py verify dfa
    python3 validators.py verify pda
"""
import sys
import re
import random
import string
import itertools
import ipaddress
from functools import lru_cache

TRAP = "trap"


# --------------------------------------------------------------------------
# Table-driven DFA runner
# --------------------------------------------------------------------------
class DFA:
    def __init__(self, name, start, accepting, delta, classify):
        self.name, self.start = name, start
        self.accepting, self.delta, self.classify = set(accepting), delta, classify

    def step(self, q, ch):
        return TRAP if q == TRAP else self.delta.get((q, self.classify(ch)), TRAP)

    def run(self, w):
        q = self.start
        for ch in w:
            q = self.step(q, ch)
            if q == TRAP:
                break
        return q

    def accepts(self, w):
        return self.run(w) in self.accepting

    def trace(self, w):
        out, q = [f"Trace of {w}:"], self.start
        for ch in w:
            cls = self.classify(ch)
            nxt = self.step(q, ch)
            out.append(f"delta({q}, '{ch}' -> {cls}) = {nxt}")
            q = nxt
            if q == TRAP:
                break
        out.append(f"final state {q}: " + ("ACCEPTED" if q in self.accepting else "REJECTED"))
        return out

    def states(self):
        seen, todo = {self.start}, [self.start]
        symbols = {c for (_, c) in self.delta}
        while todo:
            q = todo.pop()
            for c in symbols:
                r = self.delta.get((q, c), TRAP)
                if r not in seen:
                    seen.add(r)
                    todo.append(r)
        return seen

    def minimal_size(self):
        """Number of Moore equivalence classes of reachable states (trap included)."""
        sts = sorted(self.states() | {TRAP})
        symbols = sorted({c for (_, c) in self.delta})
        part = {q: (q in self.accepting) for q in sts}
        while True:
            sig = {q: (part[q], tuple(part[self.delta.get((q, c), TRAP)] for c in symbols)) for q in sts}
            ids, new = {}, {}
            for q in sts:
                new[q] = ids.setdefault(sig[q], len(ids))
            if len(set(new.values())) == len(set(part.values())):
                return len(set(new.values()))
            part = new


# ---- Application 1: PAN number  AAAPA9999A -------------------------------
TYPE_LETTERS = "PCHFABLJGT"
UPPER = string.ascii_uppercase


def classify_pan(ch):
    if ch in TYPE_LETTERS:
        return "T"
    if ch in UPPER:
        return "L"
    if ch in "0123456789":
        return "D"
    return "O"


def build_pan():
    d = {}
    for i in (0, 1, 2):
        for c in "TL":
            d[(f"p{i}", c)] = f"p{i+1}"
    d[("p3", "T")] = "p4"
    for c in "TL":
        d[("p4", c)] = "p5"
    for i in (5, 6, 7, 8):
        d[(f"p{i}", "D")] = f"p{i+1}"
    for c in "TL":
        d[("p9", c)] = "p10"
    return DFA("pan", "p0", {"p10"}, d, classify_pan)


# ---- Application 2: 24-hour time HH:MM -----------------------------------
def classify_time(ch):
    if ch in "01":
        return "01"
    if ch == "2":
        return "2"
    if ch == "3":
        return "3"
    if ch in "45":
        return "45"
    if ch in "6789":
        return "69"
    if ch == ":":
        return ":"
    return "X"


def build_time():
    d = {}
    d[("S0", "01")] = "H1"
    d[("S0", "2")] = "H2"
    for c in ("01", "2", "3", "45", "69"):
        d[("H1", c)] = "HD"
    for c in ("01", "2", "3"):
        d[("H2", c)] = "HD"
    d[("HD", ":")] = "CO"
    for c in ("01", "2", "3", "45"):
        d[("CO", c)] = "M1"
    for c in ("01", "2", "3", "45", "69"):
        d[("M1", c)] = "M2"
    return DFA("time", "S0", {"M2"}, d, classify_time)


# ---- Application 3: IPv4 dotted decimal ----------------------------------
def classify_ip(ch):
    if ch in ("0", "1", "2", "5"):
        return ch
    if ch in "34":
        return "34"
    if ch in "6789":
        return "69"
    if ch == ".":
        return "."
    return "X"


DIGIT_CLASSES = ("0", "1", "2", "34", "5", "69")


def build_ip():
    d = {}
    for k in (1, 2, 3, 4):
        n, a, b, w, v, e = (f"{x}{k}" for x in "nabwve")
        d[(n, "0")] = e
        d[(n, "1")] = a
        d[(n, "2")] = b
        for c in ("34", "5", "69"):
            d[(n, c)] = w
        for c in DIGIT_CLASSES:
            d[(a, c)] = w
            d[(w, c)] = e
        for c in ("0", "1", "2", "34"):
            d[(b, c)] = w
        d[(b, "5")] = v
        d[(b, "69")] = e
        for c in ("0", "1", "2", "34", "5"):
            d[(v, c)] = e
        if k < 4:
            for s in (a, b, w, v, e):
                d[(s, ".")] = f"n{k+1}"
    return DFA("ip", "n1", {"a4", "b4", "w4", "v4", "e4"}, d, classify_ip)


PAN, TIME, IP = build_pan(), build_time(), build_ip()
DFAS = {"pan": PAN, "time": TIME, "ip": IP}

RE_PAN = re.compile(r"[A-Z]{3}[PCHFABLJGT][A-Z][0-9]{4}[A-Z]")
RE_TIME = re.compile(r"([01][0-9]|2[0-3]):[0-5][0-9]")


def ref_pan(s):
    return RE_PAN.fullmatch(s) is not None


def ref_time(s):
    return RE_TIME.fullmatch(s) is not None


def ref_ip(s):
    try:
        ipaddress.IPv4Address(s)
        return True
    except ValueError:
        return False


# --------------------------------------------------------------------------
# Generic Earley recogniser (independent reference for the grammars)
# --------------------------------------------------------------------------
def earley(grammar, start, tokens):
    nullable, changed = set(), True
    while changed:
        changed = False
        for lhs, alts in grammar.items():
            if lhs not in nullable and any(all(s in nullable for s in rhs) for rhs in alts):
                nullable.add(lhs)
                changed = True
    n = len(tokens)
    chart = [set() for _ in range(n + 1)]
    for ri in range(len(grammar[start])):
        chart[0].add((start, ri, 0, 0))
    for i in range(n + 1):
        agenda = list(chart[i])
        while agenda:
            lhs, ri, dot, org = agenda.pop()
            rhs = grammar[lhs][ri]
            new = []
            if dot < len(rhs):
                sym = rhs[dot]
                if sym in grammar:
                    new += [(sym, rj, 0, i) for rj in range(len(grammar[sym]))]
                    if sym in nullable:
                        new.append((lhs, ri, dot + 1, org))
                elif i < n and tokens[i] == sym:
                    chart[i + 1].add((lhs, ri, dot + 1, org))
            else:
                for (l2, r2, d2, o2) in list(chart[org]):
                    r = grammar[l2][r2]
                    if d2 < len(r) and r[d2] == lhs:
                        new.append((l2, r2, d2 + 1, o2))
            for it in new:
                if it not in chart[i]:
                    chart[i].add(it)
                    agenda.append(it)
    return any(l == start and d == len(grammar[l][r]) and o == 0 for (l, r, d, o) in chart[n])


# --------------------------------------------------------------------------
# Case study 1: arithmetic expressions
# --------------------------------------------------------------------------
G1 = {"E": [["E", "+", "E"], ["E", "*", "E"], ["(", "E", ")"], ["id"]]}  # ambiguous
G2 = {  # unambiguous, LL(1)
    "E": [["T", "E'"]],
    "E'": [["+", "T", "E'"], []],
    "T": [["F", "T'"]],
    "T'": [["*", "F", "T'"], []],
    "F": [["(", "E", ")"], ["id"]],
}
LL1 = {
    ("E", "id"): ["T", "E'"], ("E", "("): ["T", "E'"],
    ("E'", "+"): ["+", "T", "E'"], ("E'", ")"): [], ("E'", "$"): [],
    ("T", "id"): ["F", "T'"], ("T", "("): ["F", "T'"],
    ("T'", "+"): [], ("T'", "*"): ["*", "F", "T'"], ("T'", ")"): [], ("T'", "$"): [],
    ("F", "id"): ["id"], ("F", "("): ["(", "E", ")"],
}
NONTERMS = {"E", "E'", "T", "T'", "F"}


def tokenize(s):
    toks = re.findall(r"id|[+*()]", s)
    return toks if "".join(toks) == s else None


def fmt_stack(stack):
    return " ".join(reversed(stack))


def expr_run(tokens, trace=False):
    """Predictive (LL(1)) pushdown parser; returns (accepted, trace_lines)."""
    toks, i = list(tokens) + ["$"], 0
    stack, lines = ["Z0", "E"], []
    rest = lambda: "".join(toks[i:-1]) or "e"
    lines.append(f"(q0, {''.join(tokens)}, Z0)")
    lines.append(f"|- (q1, {rest()}, {fmt_stack(stack)})   push E")
    while True:
        top, a = stack[-1], toks[i]
        if top == "Z0":
            ok = a == "$"
            if ok:
                lines.append("|- (qf, e, Z0)")
            else:
                lines.append(f"no move: Z0 on top but input {rest()} remains -> REJECTED")
            return ok, lines
        if top in NONTERMS:
            rule = LL1.get((top, a))
            if rule is None:
                lines.append(f"no move: {top} with lookahead {'end' if a == '$' else a} -> REJECTED")
                return False, lines
            stack.pop()
            stack.extend(reversed(rule))
            lines.append(f"|- (q1, {rest()}, {fmt_stack(stack)})   {top} -> {' '.join(rule) or 'e'}")
        else:
            if top != a:
                lines.append(f"no move: {top} on top, input {'end' if a == '$' else a} -> REJECTED")
                return False, lines
            stack.pop()
            i += 1
            lines.append(f"|- (q1, {rest()}, {fmt_stack(stack)})   match {top}")


@lru_cache(maxsize=None)
def _count(toks, i, j):
    """Number of parse trees of toks[i:j] in the ambiguous grammar G1."""
    if j - i == 1:
        return 1 if toks[i] == "id" else 0
    total = 0
    if j - i >= 3 and toks[i] == "(" and toks[j - 1] == ")":
        total += _count(toks, i + 1, j - 1)
    for k in range(i + 1, j - 1):
        if toks[k] in ("+", "*"):
            total += _count(toks, i, k) * _count(toks, k + 1, j)
    return total


def count_trees(tokens):
    return _count(tuple(tokens), 0, len(tokens))


# --------------------------------------------------------------------------
# Case study 2: palindromes with a nondeterministic PDA
# --------------------------------------------------------------------------
def pda_moves(variant, state, rest, stack):
    """All moves of the palindrome PDA from one configuration."""
    moves, top = [], stack[0]
    x = rest[0] if rest else None
    if variant == "even":
        if state == "q0":
            if x in ("a", "b"):
                moves.append(("q0", rest[1:], x + stack))
            moves.append(("q1", rest, stack))               # guess: middle reached
        elif state == "q1":
            if x is not None and top == x:
                moves.append(("q1", rest[1:], stack[1:]))
            if top == "Z" and not rest:
                moves.append(("qf", rest, stack))
    else:  # marked: w c w^R, deterministic
        if state == "q0":
            if x in ("a", "b"):
                moves.append(("q0", rest[1:], x + stack))
            elif x == "c":
                moves.append(("q1", rest[1:], stack))
        elif state == "q1":
            if x is not None and top == x:
                moves.append(("q1", rest[1:], stack[1:]))
            if top == "Z" and not rest:
                moves.append(("qf", rest, stack))
    return moves


def pda_run(variant, w):
    """Breadth-first search over configurations. Returns (accepted, witness, explored, max_branch)."""
    start = ("q0", w, "Z")
    parent, frontier, explored, max_branch = {start: None}, [start], 0, 0
    witness = None
    while frontier:
        nxt = []
        for cfg in frontier:
            explored += 1
            s, rest, stack = cfg
            if s == "qf" and not rest and witness is None:
                witness = cfg
            mv = pda_moves(variant, s, rest, stack)
            max_branch = max(max_branch, len(mv))
            for m in mv:
                if m not in parent:
                    parent[m] = cfg
                    nxt.append(m)
        frontier = nxt
    path = []
    if witness:
        c = witness
        while c:
            path.append(c)
            c = parent[c]
        path.reverse()
    return witness is not None, path, explored, max_branch


def show_cfg(c):
    return f"({c[0]}, {c[1] or 'e'}, {c[2][:-1]}Z0)"


def pda_trace(variant, w):
    ok, path, explored, mb = pda_run(variant, w)
    out = [f"Trace of {w or 'e'}:"]
    if ok:
        out.append(show_cfg(path[0]))
        out += ["|- " + show_cfg(c) for c in path[1:]]
        out.append(f"ACCEPTED ({explored} configurations explored)")
    else:
        out.append(f"(q0, {w or 'e'}, Z0)")
        out.append(f"all branches die ({explored} configurations explored) -> REJECTED")
    return out


def ref_even_pal(s):
    return set(s) <= {"a", "b"} and s == s[::-1] and len(s) % 2 == 0


def ref_marked(s):
    parts = s.split("c")
    return len(parts) == 2 and set(parts[0] + parts[1]) <= {"a", "b"} and parts[0] == parts[1][::-1]


# --------------------------------------------------------------------------
# Case study 3: floating-point literal (a CFG that is regular)
# --------------------------------------------------------------------------
G3 = {
    "S": [["Sg", "Mt", "Ex"]],
    "Sg": [[], ["+"], ["-"]],
    "Mt": [["Ds"], ["Ds", "."], ["Ds", ".", "Ds"], [".", "Ds"]],
    "Ex": [[], ["e", "Sg", "Ds"], ["E", "Sg", "Ds"]],
    "Ds": [["d"], ["d", "Ds"]],
}
RE_FLOAT = re.compile(r"[+-]?([0-9]+(\.[0-9]*)?|\.[0-9]+)([eE][+-]?[0-9]+)?")


def classify_float(ch):
    if ch in "0123456789":
        return "d"
    if ch in "+-":
        return "s"
    if ch == ".":
        return "."
    if ch in "eE":
        return "e"
    return "X"


def build_float():
    # f0 start, f1 sign read, f2 integer digits, f3 leading '.', f4 after '.' with
    # or without fraction digits (accepting), f5 after e/E, f6 exponent sign, f7 exponent digits
    d = {
        ("f0", "s"): "f1", ("f0", "d"): "f2", ("f0", "."): "f3",
        ("f1", "d"): "f2", ("f1", "."): "f3",
        ("f2", "d"): "f2", ("f2", "."): "f4", ("f2", "e"): "f5",
        ("f3", "d"): "f4",
        ("f4", "d"): "f4", ("f4", "e"): "f5",
        ("f5", "s"): "f6", ("f5", "d"): "f7",
        ("f6", "d"): "f7",
        ("f7", "d"): "f7",
    }
    return DFA("float", "f0", {"f2", "f4", "f7"}, d, classify_float)


FLOAT = build_float()


def float_cfg(s):
    toks = [("d" if c in "0123456789" else c) for c in s]
    return earley(G3, "S", toks)


def ref_float(s):
    return RE_FLOAT.fullmatch(s) is not None


# --------------------------------------------------------------------------
# Commands
# --------------------------------------------------------------------------
def verdict(ok):
    return "ACCEPT" if ok else "REJECT"


def table_dfa():
    sets = [
        ("PAN number DFA", PAN, ["ABCPE1234F", "AAAAA0000A", "ZZZTZ9999Z", "ABCDE1234F", "ABCPE123F", "abcpe1234f", "ABCPE12345"]),
        ("24-hour time DFA", TIME, ["00:00", "09:30", "23:59", "24:00", "12:60", "7:45", "12-30"]),
        ("IPv4 address DFA", IP, ["192.168.1.1", "0.0.0.0", "255.255.255.255", "256.1.1.1", "01.2.3.4", "1.2.3", "1.2.3.4."]),
    ]
    out = ["$ python3 validators.py table dfa"]
    for title, m, cases in sets:
        out.append(f"== {title} ({len(m.states() | {TRAP})} states) ==")
        for w in cases:
            q = m.run(w)
            out.append(f"{w:<17}{verdict(q in m.accepting):<8} ({q})")
        out.append("")
    return out[:-1]


def table_pda():
    out = ["$ python3 validators.py table pda", "== Expressions (DPDA) =="]
    for w in ["id+id*id", "(id+id)*id", "id*(id)", "id+", "id id", "(id"]:
        t = tokenize(w)
        ok = bool(t) and expr_run(t)[0]
        out.append(f"{w:<14}{verdict(ok)}")
    out += ["", "== Palindromes (NPDA) =="]
    for w in ["abba", "baab", "aabbaa", "e", "abab", "aba", "abbb"]:
        s = "" if w == "e" else w
        out.append(f"{w:<14}{verdict(pda_run('even', s)[0])}")
    out += ["", "== Float literals (CFG / DFA) =="]
    for w in ["3.14", "-0.5e10", ".5", "5.", "1e+9", "1e", "e5"]:
        assert float_cfg(w) == FLOAT.accepts(w) == ref_float(w)
        out.append(f"{w:<14}{verdict(FLOAT.accepts(w))}")
    return out


def cmd_trace(kind, w):
    out = [f"$ python3 validators.py trace {kind} {w}"]
    if kind in DFAS:
        out += DFAS[kind].trace(w)
    elif kind == "float":
        out += FLOAT.trace(w)
    elif kind == "expr":
        toks = tokenize(w)
        if toks is None:
            out += ["not a token string -> REJECTED"]
        else:
            out.append(f"Trace of {w}:")
            ok, lines = expr_run(toks)
            out += lines + ["ACCEPTED" if ok else ""]
            if not ok:
                out.pop()
    elif kind in ("pal", "marked"):
        out += pda_trace("even" if kind == "pal" else "marked", w)
    return out


def all_strings(alphabet, lo, hi):
    for n in range(lo, hi + 1):
        for t in itertools.product(alphabet, repeat=n):
            yield "".join(t)


def mutate(s, alphabet, rng):
    s = list(s)
    for _ in range(rng.choice([1, 1, 2])):
        op = rng.choice("sid")
        if op == "s" and s:
            s[rng.randrange(len(s))] = rng.choice(alphabet)
        elif op == "i":
            s.insert(rng.randrange(len(s) + 1), rng.choice(alphabet))
        elif s:
            del s[rng.randrange(len(s))]
    return "".join(s)


def verify_dfa():
    rng = random.Random(2026)
    rows = []

    def check(name, m, ref, strings, label):
        n = bad = acc = 0
        for w in strings:
            n += 1
            a, r = m.accepts(w), ref(w)
            acc += r
            bad += a != r
        rows.append((name, n, label, bad, acc))

    check("pan", PAN, ref_pan, all_strings("AZ1", 0, 11), "length 0-11 over {A,Z,1}")
    check("time", TIME, ref_time, all_strings("0123456:", 0, 6), "length 0-6 over {0-6,:}")
    check("ip", IP, ref_ip, all_strings("0256.", 0, 9), "length 0-9 over {0,2,5,6,.}")

    def rand_pan():
        base = "".join(rng.choice(UPPER) for _ in range(3)) + rng.choice(TYPE_LETTERS) + rng.choice(UPPER) \
               + "".join(rng.choice("0123456789") for _ in range(4)) + rng.choice(UPPER)
        return mutate(base, UPPER + "0123456789a-", rng) if rng.random() < 0.8 else base

    def rand_time():
        base = f"{rng.randrange(0, 24):02d}:{rng.randrange(0, 60):02d}"
        return mutate(base, "0123456789:a ", rng) if rng.random() < 0.8 else base

    def rand_ip():
        base = ".".join(str(rng.randrange(0, 256)) for _ in range(4))
        return mutate(base, "0123456789.a", rng) if rng.random() < 0.85 else base

    check("pan+", PAN, ref_pan, (rand_pan() for _ in range(100000)), "random mutated inputs")
    check("time+", TIME, ref_time, (rand_time() for _ in range(100000)), "random mutated inputs")
    check("ip+", IP, ref_ip, (rand_ip() for _ in range(100000)), "random mutated inputs")
    out = ["$ python3 validators.py verify dfa"]
    for name, n, label, bad, acc in rows:
        out.append(f"{name:<6}{n:>9,} strings  {label:<27}{acc:>7,} valid   {bad} mismatches {'OK' if bad == 0 else 'FAIL'}")
    return out, rows


def verify_pda():
    rng = random.Random(7)
    rows = []

    # expressions: DPDA vs Earley on the ambiguous grammar
    n = bad = acc = 0
    for L in range(1, 8):
        for t in itertools.product(["id", "+", "*", "(", ")"], repeat=L):
            n += 1
            a = expr_run(t)[0]
            r = earley(G1, "E", list(t))
            acc += r
            bad += a != r
    rows.append(("expr", n, "length 1-7 over {id,+,*,(,)}", "DPDA vs Earley(G1)", bad, acc))

    n = bad = acc = 0
    for w in all_strings("ab", 0, 14):
        n += 1
        a, r = pda_run("even", w)[0], ref_even_pal(w)
        acc += r
        bad += a != r
    rows.append(("pal", n, "length 0-14 over {a,b}", "NPDA vs reverse check", bad, acc))

    n = bad = acc = 0
    mb = 0
    for w in all_strings("abc", 0, 9):
        n += 1
        ok, _, _, b = pda_run("marked", w)
        mb = max(mb, b)
        r = ref_marked(w)
        acc += r
        bad += ok != r
    rows.append(("marked", n, "length 0-9 over {a,b,c}", f"DPDA vs reverse (max {mb} move)", bad, acc))

    n = bad = acc = 0
    for w in all_strings("1.e+-", 0, 7):
        n += 1
        a, g, r = FLOAT.accepts(w), float_cfg(w), ref_float(w)
        acc += r
        bad += (a != r) or (g != r)
    rows.append(("float", n, "length 0-7 over {1,.,e,+,-}", "DFA, CFG vs regex", bad, acc))

    n = bad = accr = 0
    for _ in range(60000):
        L = rng.randrange(1, 14)
        w = "".join(rng.choice("0123456789..eE+-+-x") for _ in range(L))
        n += 1
        accr += ref_float(w)
        bad += (FLOAT.accepts(w) != ref_float(w))
    rows.append(("float+", n, "random, length 1-13", "DFA vs regex", bad, accr))

    out = ["$ python3 validators.py verify pda"]
    for name, n, label, what, bad, acc in rows:
        out.append(f"{name:<7}{n:>7,} strings  {label:<29}{what:<31}{acc:>6,} valid   {bad} mismatches {'OK' if bad == 0 else 'FAIL'}")
    return out, rows


def main(argv):
    if len(argv) >= 3 and argv[1] == "table":
        print("\n".join(table_dfa() if argv[2] == "dfa" else table_pda()))
    elif len(argv) >= 4 and argv[1] == "trace":
        print("\n".join(cmd_trace(argv[2], argv[3] if argv[3] != "e" else "")))
    elif len(argv) >= 3 and argv[1] == "verify":
        out, _ = verify_dfa() if argv[2] == "dfa" else verify_pda()
        print("\n".join(out))
    else:
        print(__doc__)


if __name__ == "__main__":
    main(sys.argv)
