import re
import subprocess
import itertools
from PIL import Image, ImageDraw, ImageFont
import validators as v

import os
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "fig")
subprocess.run(["mkdir", "-p", OUT])

# ------------------------------------------------------------------ terminal
MONO = "/usr/share/fonts/truetype/dejavu/DejaVuSansMono.ttf"
MONOB = "/usr/share/fonts/truetype/dejavu/DejaVuSansMono-Bold.ttf"
SIZE = 15
F, FB = ImageFont.truetype(MONO, SIZE), ImageFont.truetype(MONOB, SIZE)
CW = F.getlength("M")
LH = SIZE + 6
BG, BAR, FG = (27, 31, 39), (43, 48, 59), (215, 218, 224)
BLUE, YEL, GRN, RED = (97, 175, 239), (229, 192, 123), (152, 195, 121), (224, 108, 117)
WORDS = re.compile(r"(ACCEPTED|ACCEPT|REJECTED|REJECT|OK|FAIL|\d+ mismatches)")


def color_for(tok, line):
    if tok in ("ACCEPTED", "ACCEPT", "OK") or tok.endswith("mismatches") and tok.startswith("0 "):
        return GRN, True
    if tok in ("REJECTED", "REJECT", "FAIL") or tok.endswith("mismatches"):
        return RED, True
    return FG, False


def term(title, lines, min_chars=60):
    n = max(min_chars, max(len(l) for l in lines) + 2)
    w, h = int(n * CW + 36), 34 + LH * len(lines) + 24
    im = Image.new("RGB", (w, h), BG)
    d = ImageDraw.Draw(im)
    d.rectangle([0, 0, w, 30], fill=BAR)
    for i, c in enumerate([(237, 106, 94), (245, 191, 79), (97, 197, 84)]):
        d.ellipse([14 + i * 20, 9, 26 + i * 20, 21], fill=c)
    d.text((82, 8), title, font=ImageFont.truetype(MONO, 13), fill=(150, 156, 168))
    y = 42
    for line in lines:
        x = 18
        if line.startswith("$"):
            d.text((x, y), line, font=FB, fill=BLUE)
        elif line.startswith("=="):
            d.text((x, y), line, font=FB, fill=YEL)
        else:
            for part in WORDS.split(line):
                if not part:
                    continue
                col, bold = color_for(part, line) if WORDS.fullmatch(part) else (FG, False)
                if line.startswith("no move") or line.startswith("all branches"):
                    col, bold = (RED, True) if not WORDS.fullmatch(part) else color_for(part, line)
                d.text((x, y), part, font=FB if bold else F, fill=col)
                x += CW * len(part)
        y += LH
    return im


def side_by_side(a, b, gap=14):
    h = max(a.height, b.height)
    im = Image.new("RGB", (a.width + gap + b.width, h), (255, 255, 255))
    im.paste(a, (0, 0))
    im.paste(b, (a.width + gap, 0))
    return im


def stack(images, gap=12):
    w = max(i.width for i in images)
    h = sum(i.height for i in images) + gap * (len(images) - 1)
    im = Image.new("RGB", (w, h), (255, 255, 255))
    y = 0
    for i in images:
        im.paste(i, (0, y))
        y += i.height + gap
    return im


def lines_of(fn, *a):
    return fn(*a)


def save(im, name):
    im.save(f"{OUT}/{name}.png")
    print(name, im.size)


# Fig. 4: DFA verdicts (left) and two rejected traces (right); Fig. 5: verify
t1 = term("validators - trace", v.cmd_trace("pan", "ABCDE1234F"), 50)
t2 = term("validators - trace", v.cmd_trace("ip", "256.1.1.1"), 50)
save(side_by_side(term("validators - table", v.table_dfa(), 70), stack([t1, t2])), "fig4_table_trace_dfa")
vo, _ = v.verify_dfa()
save(term("validators - verify", vo, 100), "fig5_verify_dfa")

# Fig. 11: PDA verdicts (left) and palindrome traces (right); Fig. 12: expression traces; Fig. 13: verify
right = stack([
    term("validators - trace", v.cmd_trace("pal", "abba"), 50),
    term("validators - trace", v.cmd_trace("pal", "abab"), 50),
    term("validators - trace", v.cmd_trace("marked", "abcba"), 50),
])
save(side_by_side(term("validators - table", v.table_pda(), 70), right), "fig11_table_trace_pda")
left = term("validators - trace", v.cmd_trace("expr", "id+id*id") + [""] + v.cmd_trace("expr", "id+*id")[:1] + v.cmd_trace("expr", "id+*id")[2:], 62)
save(left, "fig12_traces_expr")
po, _ = v.verify_pda()
save(term("validators - verify", po, 100), "fig13_verify_pda")


# ------------------------------------------------------------------ graphviz
def dot(name, src, dpi=220):
    open(f"{OUT}/{name}.dot", "w").write(src)
    subprocess.run(["dot", "-Tpng", f"-Gdpi={dpi}", f"{OUT}/{name}.dot", "-o", f"{OUT}/{name}.png"], check=True)
    im = Image.open(f"{OUT}/{name}.png")
    print(name, im.size)


HEAD = '''digraph G { rankdir=LR; bgcolor="white"; nodesep=0.25; ranksep=%s; pad=0.1;
 node [shape=circle, fontname="Liberation Serif", fontsize=%d, width=%s, fixedsize=true, penwidth=0.9];
 edge [fontname="Liberation Serif", fontsize=%d, arrowsize=0.6, penwidth=0.9];
 start [shape=point, width=0.08, label=""];
'''


def dfa_dot(states, acc, edges, first, rs="0.32", fs=10, w="0.42", efs=9):
    s = HEAD % (rs, fs, w, efs)
    for q in states:
        s += f' {q} [label="{q}"{", shape=doublecircle" if q in acc else ""}];\n'
    s += f" start -> {first};\n"
    for a, b, l in edges:
        s += f' {a} -> {b} [label="{l}"];\n'
    return s + "}\n"


# Fig. 1 PAN
pan_edges = [("p0", "p1", "L,T"), ("p1", "p2", "L,T"), ("p2", "p3", "L,T"), ("p3", "p4", "T"), ("p4", "p5", "L,T"),
             ("p5", "p6", "D"), ("p6", "p7", "D"), ("p7", "p8", "D"), ("p8", "p9", "D"), ("p9", "p10", "L,T")]
dot("fig1_pan", dfa_dot([f"p{i}" for i in range(11)], {"p10"}, pan_edges, "p0", rs="0.28", fs=9, w="0.38", efs=9))

# Fig. 2 time
time_edges = [("S0", "H1", "0,1"), ("S0", "H2", "2"), ("H1", "HD", "0–9"), ("H2", "HD", "0–3"),
              ("HD", "CO", "&#58;"), ("CO", "M1", "0–5"), ("M1", "M2", "0–9")]
dot("fig2_time", dfa_dot(["S0", "H1", "H2", "HD", "CO", "M1", "M2"], {"M2"}, time_edges, "S0", rs="0.45", w="0.5"))

# Fig. 3 IPv4 (octet 1 expanded; octets 2-4 share the same shape)
ip = '''digraph G { rankdir=LR; compound=true; nodesep=0.22; ranksep=0.4; pad=0.1;
 node [shape=circle, fontname="Liberation Serif", fontsize=10, width=0.42, fixedsize=true, penwidth=0.9];
 edge [fontname="Liberation Serif", fontsize=9, arrowsize=0.6, penwidth=0.9];
 start [shape=point, width=0.08, label=""];
 subgraph cluster_o1 { label="octet 1"; fontname="Liberation Serif"; fontsize=10; style=rounded; color="#777777";
   n1; a1; b1; w1; v1; e1; }
 o2 [shape=box, style=rounded, fixedsize=false, width=0.5, label="octet 2\\nn2 a2 b2 w2 v2 e2", fontsize=9];
 o3 [shape=box, style=rounded, fixedsize=false, width=0.5, label="octet 3\\nn3 a3 b3 w3 v3 e3", fontsize=9];
 o4 [shape=box, style="rounded", peripheries=2, fixedsize=false, width=0.5, label="octet 4\\nn4 a4 b4 w4 v4 e4\\naccepting: a4 b4 w4 v4 e4", fontsize=9];
 start -> n1;
 n1 -> e1 [label="0"]; n1 -> a1 [label="1"]; n1 -> b1 [label="2"]; n1 -> w1 [label="3–9"];
 a1 -> w1 [label="0–9"]; b1 -> w1 [label="0–4"]; b1 -> v1 [label="5"]; b1 -> e1 [label="6–9"];
 w1 -> e1 [label="0–9"]; v1 -> e1 [label="0–5"];
 e1 -> o2 [label="'.'  (from a1, b1, w1, v1, e1)", ltail=cluster_o1];
 o2 -> o3 [label="'.'"]; o3 -> o4 [label="'.'"];
}
'''
dot("fig3_ip", ip)

# Fig. 6/7 parse trees
cnt = itertools.count()


def tree_dot(trees, titles, fname):
    s = 'digraph G { bgcolor="white"; nodesep=0.18; ranksep=0.32; pad=0.1;\n node [shape=plaintext, fontname="Liberation Serif", fontsize=13, height=0.2, width=0.2];\n edge [arrowhead=none, penwidth=0.8];\n'

    def emit(node):
        nid = f"n{next(cnt)}"
        if isinstance(node, str):
            s_ = f' {nid} [label="{node}", fontname="Liberation Mono"];\n'
            return nid, s_
        label, kids = node
        body = f' {nid} [label="{label}"];\n'
        for k in kids:
            kid, ks = emit(k)
            body += ks + f" {nid} -> {kid};\n"
        return nid, body

    for i, (t, ttl) in enumerate(zip(trees, titles)):
        s += f' subgraph cluster_{i} {{ label="{ttl}"; fontname="Liberation Serif"; fontsize=12; color="white";\n'
        rid, body = emit(t)
        s += body + " }\n"
    s += "}\n"
    dot(fname, s)


E = lambda *k: ("E", list(k))
t_a = E(E("id"), "+", E(E("id"), "*", E("id")))
t_b = E(E(E("id"), "+", E("id")), "*", E("id"))
tree_dot([t_a, t_b], ["(a)  id + (id * id)", "(b)  (id + id) * id"], "fig6_trees_ambiguous")


def parse_ll1(tokens):
    pos = [0]
    peek = lambda: tokens[pos[0]] if pos[0] < len(tokens) else "$"

    def eat(t):
        assert peek() == t
        pos[0] += 1
        return t

    def E_():
        return ("E", [T_(), Ep()])

    def Ep():
        return ("E'", [eat("+"), T_(), Ep()]) if peek() == "+" else ("E'", ["ε"])

    def T_():
        return ("T", [F_(), Tp()])

    def Tp():
        return ("T'", [eat("*"), F_(), Tp()]) if peek() == "*" else ("T'", ["ε"])

    def F_():
        return ("F", [eat("("), E_(), eat(")")]) if peek() == "(" else ("F", [eat("id")])

    return E_()


tree_dot([parse_ll1(["id", "+", "id", "*", "id"])], ["id + id * id"], "fig7_tree_ll1")

# Fig. 8 expression DPDA, Fig. 9 palindrome NPDA
pda_head = '''digraph G { rankdir=LR; nodesep=0.5; ranksep=0.9; pad=0.1;
 node [shape=circle, fontname="Liberation Serif", fontsize=14, width=0.55, penwidth=1];
 edge [fontname="Liberation Serif", fontsize=11, arrowsize=0.7, penwidth=1];
 start [shape=point, width=0.1, label=""];
 qf [shape=doublecircle];
 start -> q0;
'''
dot("fig8_pda_expr", pda_head + ''' q0 -> q1 [label="ε, Z0 / E Z0"];
 q1 -> q1 [label="nonterminal A on top, lookahead a:\\nreplace A by the right side in Table 5\\ntoken t on top, input t / pop"];
 q1 -> qf [label="end of input, Z0 / Z0"];
}
''')
dot("fig9_npda_pal", pda_head + ''' q0 -> q0 [label="x, any / push x\\n(x = a or b)"];
 q0 -> q1 [label="ε, any / same\\n(guess: middle reached)"];
 q1 -> q1 [label="x, x / pop"];
 q1 -> qf [label="ε, Z0 / Z0"];
}
''')

# Fig. 10 float DFA
fl_edges = [("f0", "f1", "s"), ("f0", "f2", "d"), ("f0", "f3", "."), ("f1", "f2", "d"), ("f1", "f3", "."),
            ("f2", "f2", "d"), ("f2", "f4", "."), ("f2", "f5", "e"), ("f3", "f4", "d"), ("f4", "f4", "d"),
            ("f4", "f5", "e"), ("f5", "f6", "s"), ("f5", "f7", "d"), ("f6", "f7", "d"), ("f7", "f7", "d")]
dot("fig10_float", dfa_dot([f"f{i}" for i in range(8)], {"f2", "f4", "f7"}, fl_edges, "f0", rs="0.4", w="0.45"))
