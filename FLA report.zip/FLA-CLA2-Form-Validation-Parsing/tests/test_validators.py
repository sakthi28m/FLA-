import os, sys
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import pytest
import validators as v

DFA_CASES = {
    "pan": (v.PAN, ["ABCPE1234F", "AAAAA0000A", "ZZZTZ9999Z"],
            ["ABCDE1234F", "ABCPE123F", "ABCPE12345", "abcpe1234f", "ABCPE1234FA"]),
    "time": (v.TIME, ["00:00", "09:30", "23:59"], ["24:00", "12:60", "7:45", "12-30", "23:5"]),
    "ip": (v.IP, ["192.168.1.1", "0.0.0.0", "255.255.255.255"],
           ["256.1.1.1", "01.2.3.4", "1.2.3", "1.2.3.4.", "1.2.3.4.5"]),
    "float": (v.FLOAT, ["3.14", "-0.5e10", ".5", "5.", "1e+9"], ["1e", "e5", ".", "1.2.3", "+-1", "1e2.5"]),
}


@pytest.mark.parametrize("name", DFA_CASES)
def test_dfa_accepts_and_rejects(name):
    m, good, bad = DFA_CASES[name]
    assert all(m.accepts(w) for w in good)
    assert not any(m.accepts(w) for w in bad)


@pytest.mark.parametrize("name,size", [("pan", 12), ("time", 8), ("ip", 25), ("float", 9)])
def test_state_counts_and_minimality(name, size):
    m = DFA_CASES[name][0]
    assert len(m.states() | {v.TRAP}) == size
    assert m.minimal_size() == size


def test_expression_dpda():
    for w in ["id", "id+id*id", "(id+id)*id", "((id))", "id*(id+id)*id"]:
        assert v.expr_run(v.tokenize(w))[0]
    for w in ["id+", "+id", "(id", "id)", "()", "id**id", "idid"]:
        assert not v.expr_run(v.tokenize(w))[0]


def test_ambiguity_counts():
    assert v.count_trees(["id", "+", "id", "*", "id"]) == 2
    assert v.count_trees(["id", "+", "id", "+", "id", "+", "id"]) == 5


def test_palindrome_npda_and_marked_dpda():
    for w in ["", "aa", "abba", "baab", "aabbaa"]:
        assert v.pda_run("even", w)[0]
    for w in ["a", "ab", "aba", "abab", "abbb"]:
        assert not v.pda_run("even", w)[0]
    assert v.pda_run("marked", "abcba")[0] and not v.pda_run("marked", "abcab")[0]
    assert max(v.pda_run("marked", w)[3] for w in v.all_strings("abc", 0, 7)) == 1


def test_matches_independent_references_small():
    assert all(v.PAN.accepts(w) == v.ref_pan(w) for w in v.all_strings("AZ1", 0, 10))
    assert all(v.TIME.accepts(w) == v.ref_time(w) for w in v.all_strings("0123456:", 0, 5))
    assert all(v.IP.accepts(w) == v.ref_ip(w) for w in v.all_strings("0256.", 0, 8))
    assert all(v.FLOAT.accepts(w) == v.ref_float(w) == v.float_cfg(w) for w in v.all_strings("1.e+-", 0, 6))
